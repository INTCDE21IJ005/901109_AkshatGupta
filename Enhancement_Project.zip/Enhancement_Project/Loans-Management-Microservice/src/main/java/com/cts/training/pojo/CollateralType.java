package com.cts.training.pojo;

/**
 * Collateral Type ENUM
 */
public enum CollateralType {

	REAL_ESTATE, CASH_DEPOSIT
}
