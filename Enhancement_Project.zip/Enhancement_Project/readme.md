
								H2 Console 

![1](https://user-images.githubusercontent.com/84323941/118850837-cadadb80-b8ee-11eb-8361-2a8796a2e20b.JPG)

																		

![2](https://user-images.githubusercontent.com/84323941/118850984-f1007b80-b8ee-11eb-941c-21b789a06009.JPG)

								  Home Page
										
![3](https://user-images.githubusercontent.com/84323941/118851040-ffe72e00-b8ee-11eb-9da7-2b24f0006c93.JPG)


								Check Application Status 
![4](https://user-images.githubusercontent.com/84323941/118851338-42a90600-b8ef-11eb-9c6a-c28f19fbf52c.JPG)


								Loan Details
![5](https://user-images.githubusercontent.com/84323941/118851392-53597c00-b8ef-11eb-9aa3-af5c1fcce8b4.JPG)

								Apply Loan

![6](https://user-images.githubusercontent.com/84323941/118851398-55233f80-b8ef-11eb-8e45-ff120a7b7c26.JPG)
